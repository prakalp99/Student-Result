const express = require('express');
const Result = require('../models/Result');
const router = express.Router();

// Get result by PRN
router.get('/:prn', async (req, res) => {
    try {
        const result = await Result.findOne({ prn: req.params.prn });
        if (!result) {
            return res.status(404).json({ message: "Result not found" });
        }
        res.json(result);
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

// Update result by PRN
router.put('/:prn', async (req, res) => {
    try {
        const updatedResult = await Result.findOneAndUpdate(
            { prn: req.params.prn },
            req.body,
            { new: true }
        );
        if (!updatedResult) {
            return res.status(404).json({ message: "Result not found" });
        }
        res.json(updatedResult);
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

// Delete result by PRN
router.delete('/:prn', async (req, res) => {
    try {
        await Result.findOneAndDelete({ prn: req.params.prn });
        res.json({ message: "Result deleted" });
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

module.exports = router;
