const mongoose = require('mongoose');

const ResultSchema = new mongoose.Schema({
    name: String,
    email: String,
    prn: String,
    class: String,
    marks: Object
});

module.exports = mongoose.model('Result', ResultSchema);
