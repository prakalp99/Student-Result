const API_URL = 'http://localhost:5000/results';
let currentPRN = "";

// Fetch result by PRN
async function fetchResult() {
    const prn = document.getElementById('prn-input').value.trim();
    const errorMessage = document.getElementById('error-message');
    const resultContainer = document.getElementById('result-container');
    const resultBody = document.getElementById('result-body');

    if (!prn) {
        errorMessage.innerText = "Please enter a PRN number.";
        errorMessage.style.display = "block";
        resultContainer.style.display = "none";
        return;
    }

    try {
        const response = await fetch(`${API_URL}/${prn}`);
        const result = await response.json();

        if (!result || Object.keys(result).length === 0) {
            errorMessage.innerText = "No result found.";
            errorMessage.style.display = "block";
            resultContainer.style.display = "none";
            return;
        }

        errorMessage.style.display = "none";
        resultContainer.style.display = "block";
        resultBody.innerHTML = `
            <tr>
                <td>${result.name}</td>
                <td>${result.email}</td>
                <td>${result.prn}</td>
                <td>${result.class}</td>
                <td>${JSON.stringify(result.marks)}</td>
            </tr>
        `;

        currentPRN = result.prn;
    } catch (error) {
        errorMessage.innerText = "Error fetching result.";
        errorMessage.style.display = "block";
        resultContainer.style.display = "none";
        console.error('Error:', error);
    }
}

// Show update form
function showUpdateForm() {
    document.getElementById('update-form').style.display = 'block';
}

// Update result
async function updateResult() {
    const updatedData = {
        name: document.getElementById('update-name').value,
        email: document.getElementById('update-email').value,
        class: document.getElementById('update-class').value,
        marks: JSON.parse(document.getElementById('update-marks').value)
    };

    await fetch(`${API_URL}/${currentPRN}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedData)
    });

    alert("Result updated!");
    fetchResult();
}

// Delete result
async function deleteResult() {
    await fetch(`${API_URL}/${currentPRN}`, { method: 'DELETE' });
    alert("Result deleted!");
    document.getElementById('result-container').style.display = "none";
}
